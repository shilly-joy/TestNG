package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;

public class RegistrationPage extends Testbase {
	
	 
	 
	 public static WebElement Male_Submit(WebDriver driver,WebDriverWait wait)
     {
		  element =  wait.until(ExpectedConditions.elementToBeClickable(By.id("id_gender1")));
         return element;
     }
	 public static WebElement Female_Submit(WebDriver driver,WebDriverWait wait)
     {
		  element =  wait.until(ExpectedConditions.elementToBeClickable(By.id("id_gender2")));
         return element;
     }
	 public static WebElement Firstname_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("customer_firstname"));
         return element;
     }
	 public static WebElement Lastname_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("customer_lastname"));
         return element;
     }
	 public static WebElement Password_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("passwd"));
         return element;
     }
	 public static WebElement Day_Dropdown(WebDriver driver)
     {
		  element = driver.findElement(By.id("days"));
         return element;
     }
	 public static WebElement Month_Dropdown(WebDriver driver)
     {
		  element = driver.findElement(By.id("months"));
         return element;
     }
	 public static WebElement Year_Dropdown(WebDriver driver)
     {
		  element = driver.findElement(By.id("years"));
         return element;
     }
	 public static WebElement Company_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("company"));
         return element;
     }
	 public static WebElement Address1_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("address1"));
         return element;
     }
	 public static WebElement Address2_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("address2"));
         return element;
     }
	 public static WebElement City_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("city"));
         return element;
     }
	 public static WebElement State_Dropdown(WebDriver driver)
     {
		  element = driver.findElement(By.id("id_state"));
         return element;
     }
	 public static WebElement Postcode_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("postcode"));
         return element;
     }
	 public static WebElement Country_Dropdown(WebDriver driver)
     {
		  element = driver.findElement(By.id("id_country"));
         return element;
     }
	 public static WebElement Other_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("other"));
         return element;
     }
	 public static WebElement Phone_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("phone"));
         return element;
     }
	 public static WebElement Mobile_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("phone_mobile"));
         return element;
     }
	 public static WebElement Register_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("submitAccount"));
         return element;
     }
	 
}
