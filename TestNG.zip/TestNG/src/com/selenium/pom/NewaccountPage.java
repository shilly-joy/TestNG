package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.selenium.base.Testbase;

public class NewaccountPage extends Testbase {

	 public static WebElement Email_Box(WebDriver driver)
     {
		  element = driver.findElement(By.id("email_create"));
         return element;
     }
	 public static WebElement Email_Submit(WebDriver driver)
     {
		  element = driver.findElement(By.id("SubmitCreate"));
         return element;
     }
	 
	 
}
