package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;

public class LoginPage extends Testbase{
	
	 public static WebElement Successreg_Link(WebDriver driver,WebDriverWait wait)
     {
        element = wait.until(ExpectedConditions.elementToBeClickable(By.className("icon-user")));
        return element;
     } 

	 public static WebElement Find_Element(WebDriver driver) {
		 element =driver.findElement (By.linkText("Printed Chiffon Dress"));
		 return element;

		 }
	 public static WebElement Login_Email(WebDriver driver) {
		 element =driver.findElement (By.id("email"));
		 return element;

		 }
	 public static WebElement Login_Password(WebDriver driver) {
		 element =driver.findElement (By.id("passwd"));
		 return element;

		 } 
	 public static WebElement Login_Button(WebDriver driver) {
		 element =driver.findElement (By.id("SubmitLogin"));
		 return element;

		 }
	 
}
