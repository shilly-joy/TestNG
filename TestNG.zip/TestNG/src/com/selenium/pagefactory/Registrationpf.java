package com.selenium.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.selenium.base.Testbase;

public class Registrationpf extends Testbase{
	
	final WebDriver driver;
	public Registrationpf(WebDriver driver)
	 {
		this.driver = driver;
	 }
	@FindBy(how = How.LINK_TEXT, using = "Sign in")
	public WebElement signin;
	
	@FindBy(how = How.ID, using = "email_create")
	public WebElement emailcreate;
	
	@FindBy(how = How.ID, using = "SubmitCreate")
	public WebElement submitCreate;
	
	@FindBy(how = How.ID, using = "id_gender1")
	public WebElement maleradio;
	
	@FindBy(how = How.ID, using = "id_gender2")
	public WebElement femaleradio;
	
	@FindBy(how = How.ID, using = "customer_firstname")
	public WebElement first_name;
	
	@FindBy(how = How.ID, using = "customer_lastname")
	public WebElement last_name;
	
	@FindBy(how = How.ID, using = "passwd")
	public WebElement cuspassword;
	
	@FindBy(how = How.ID, using = "days")
	public WebElement Day;
	
	@FindBy(how = How.ID, using = "months")
	public WebElement Month;
	
	@FindBy(how = How.ID, using = "years")
	public WebElement Year;
	
	@FindBy(how = How.ID, using = "company")
	public WebElement Company;
	
	@FindBy(how = How.ID, using = "address1")
	public WebElement address_1;
	
	@FindBy(how = How.ID, using = "address2")
	public WebElement address_2;
	
	@FindBy(how = How.ID, using = "city")
	public WebElement cuscity;
	
	@FindBy(how = How.ID, using = "id_state")
	public WebElement State;
	
	@FindBy(how = How.ID, using = "postcode")
	public WebElement PostCode;
	
	@FindBy(how = How.ID, using = "id_country")
	public WebElement Country;
	
	@FindBy(how = How.ID, using = "other")
	public WebElement Other;
	
	@FindBy(how = How.ID, using = "phone")
	public WebElement Phone;
	
	@FindBy(how = How.ID, using = "phone_mobile")
	public WebElement Mobile;
	
	@FindBy(how = How.ID, using = "submitAccount")
	public WebElement Submit;
}
