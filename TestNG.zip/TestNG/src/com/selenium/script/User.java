//author:shilly
package com.selenium.script;

import java.io.IOException;

import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.Try.Iretry;
import com.selenium.base.Testbase;
import com.selenium.functions.BrowserOperations;
import com.selenium.functions.ExcelAccess;
import com.selenium.functions.Legacyfunctions;
import com.selenium.util.TestUtil;


public class User extends Testbase{
	
	static boolean isTestPass=false;
	static boolean skip=false;
	static boolean fail=false;
	String url;
	
	@Parameters({"url","browser"})
	@BeforeTest(alwaysRun=true)
	public void isSkipTest(String url,String browser){//checking whether test case runmode is yes or no
		
		initialize();
		if(!TestUtil.isTestCaseRunnable(suiteAxls,this.getClass().getSimpleName())){
				
			throw new SkipException("Test Case"+this.getClass().getSimpleName()+"is skipped as runmode set to NO");//reports
		}
		this.url=url;
		Testbase.browser=browser;
		
	}
	
	@Test(/*groups={"Primary"},*/priority=0,dataProvider="RegisterData"/*,retryAnalyzer = Iretry.class*/)
	public void Usermethod(String email,String gender,String firstname,String lastname,String password,String dateofbirth,String company,String address1,
			String address2,String city,String state,String postcode,String country,String other,String phone,String mobile,String alias )throws IOException{
		//script for new user registration
		try{
		BrowserOperations.openBrowser(url, browser);
		Legacyfunctions.Registration(email,gender,firstname,lastname,password,dateofbirth,company,address1,address2,city,state,postcode,country,other,phone,mobile,alias);
		BrowserOperations.closeBrowser();
		isTestPass=true;
		}
		catch(Exception e1){
			e1.printStackTrace();
			
		}
		
		
	}
	
	@DataProvider
	public Object[][] RegisterData(){
		return TestUtil.getData(suiteAxls, this.getClass().getSimpleName()) ;
		
	}
	

	@AfterTest
	public void reportTestResult(){
		if(isTestPass)
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases", TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "PASS");
		else
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases", TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "FAIL");

	}

	@AfterMethod
	public void reportDataSetResult(){
		if(skip)
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "SKIP");
		else if(fail){
			isTestPass=false;
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "FAIL");
		}
		else
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "PASS");
	
		skip=false;
		fail=false;
		driver.quit();

	}
	
	@Test(/*groups={"Smoke"},*/dataProvider="cartData",dependsOnMethods={"Usermethod"})
	public void Addcartmethod(String Username,String Password) throws IOException
	{
		try{
			BrowserOperations.openBrowser(url,browser);
			Legacyfunctions.cartAdding(Username, Password);
			BrowserOperations.closeBrowser();
		
			isTestPass=true;
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
			
		}	
	}
	@DataProvider	
	public Object[][] cartData(){
		
		return ExcelAccess.read();
	}

}
