//author:shilly
package com.selenium.script;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.base.Testbase;
import com.selenium.functions.BrowserOperations;
import com.selenium.functions.Legacyfunctions;
import com.selenium.pom.AcceptPage;
import com.selenium.util.TestUtil;

public class Searchitems extends Testbase{
	
	static boolean isTestPass=false;
	static boolean skip=false;
	static boolean fail=false;
	String url;
	
	@Parameters({"url","browser"})
	@BeforeTest(alwaysRun=true)
	public void isSkipTest(String url,String browser){//checking whether the test case run mo0de is yes or not
		
		initialize();
		if(!TestUtil.isTestCaseRunnable(suiteAxls,this.getClass().getSimpleName())){
				
			throw new SkipException("Test Case"+this.getClass().getSimpleName()+"is skipped as runmode set to NO");//reports
		}
		this.url=url;
		Testbase.browser=browser;
		
		
	}
	
	@Test(/*groups={"Smoke"},*/priority=1,dataProvider="SearchData"/*,expectedExceptions = ArithmeticException.class*/)
	public void Searchmethod(String item)throws IOException{
		
		try{
		BrowserOperations.openBrowser(url, browser);
		Legacyfunctions.Searchitem(item);
		//Legacyfunctions.dividedByException();
		
		BrowserOperations.closeBrowser();
		isTestPass=true;
		}
		catch(Exception e1){
			e1.printStackTrace();
			
		}
		
	}
	@DataProvider
	public Object[][] SearchData(){
		return TestUtil.getData(suiteAxls, this.getClass().getSimpleName()) ;
		
	}
	
	
	@Test(priority=0,enabled=false)
	public void priorityTest(){
		System.out.println("this is the highest priority method");
	}
	
	
	
	@AfterTest
	public void reportTestResult(){
		if(isTestPass)
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases", TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "PASS");
		else
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases", TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "FAIL");

	}

	@AfterMethod
	public void reportDataSetResult(){
		if(skip)
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "SKIP");
		else if(fail){
			isTestPass=false;
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "FAIL");
		}
		else
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "PASS");
	
		skip=false;
		fail=false;
		driver.quit();

		

	}


}
