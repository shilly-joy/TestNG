package com.selenium.functions;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.selenium.base.Testbase;
import com.selenium.pagefactory.Registrationpf;
import com.selenium.pom.AcceptPage;
import com.selenium.pom.AddtocartPage;
import com.selenium.pom.HomePage;
import com.selenium.pom.LoginPage;
import com.selenium.pom.NewaccountPage;
import com.selenium.pom.RegistrationPage;

public class Legacyfunctions extends Testbase {

	public static boolean Searchitem(String searchitemname){
		/*if(browser.equals("chrome")){
		   AcceptPage.accept_click(driver, wait).click();
		}*/ 
		String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL,Keys.RETURN);

        driver.findElement(By.name("button")).sendKeys(selectLinkOpeninNewTab);

        ArrayList<String> handle= new ArrayList<String>(driver.getWindowHandles());//Return a string of alphanumeric window handle

        driver.switchTo().window(handle.get(1));
          HomePage.Search_Box(driver).sendKeys(searchitemname);
		  Assert.assertEquals(HomePage.Search_Box(driver).getAttribute("value"), searchitemname);
		  HomePage.Submit_Button(driver,wait).click();
		  element=LoginPage.Find_Element(driver);
			 if (element==null) {
				 return false;
			 }
			 else {
				 System.out.println("passed searching");
				 return true;
			 }

		  
	}
	public static boolean Registration(String email,String gender,String firstname,String lastname,String password,
			String dateofbirth,String company,String address1,String address2,String city,
			String state,String postcode,String country,String other,String phone,String mobile,String alias){
		
		Registrationpf regis = PageFactory.initElements(driver,Registrationpf .class);
		if(browser.equals("chrome")){
			AcceptPage.accept_click(driver, wait).click();
		}
		//HomePage.Signin_Link(driver,wait).click();
		 regis.signin.click(); 
		
		 Date date=new Date();
		 int e1=date.getDate();
		 long e2=date.getTime();
		 String[] emailId=email.split("@");
		 email=emailId[0]+e1+e2+"@"+emailId[1];                     
		// NewaccountPage.Email_Box(driver).sendKeys(email);
		 regis.emailcreate.sendKeys(email);
		 Assert.assertEquals( regis.emailcreate.getAttribute("value"),email);
		// NewaccountPage.Email_Submit(driver).click();
		 regis.submitCreate.click();
		 if(gender.equals("male")){
			 //RegistrationPage.Male_Submit(driver, wait).click();
			 regis.maleradio.click();
			// Assert.assertEquals(RegistrationPage.Male_Submit(driver, wait).getAttribute("value"),1);
		 }
		 else{
			// RegistrationPage.Female_Submit(driver, wait).click();
			  regis.femaleradio.click();
			 //Assert.assertEquals(RegistrationPage.Female_Submit(driver, wait).getAttribute("value"),2);
		 }
		// RegistrationPage.Firstname_Box(driver).sendKeys(firstname);
		 regis.first_name.sendKeys(firstname);
		 Assert.assertEquals(regis.first_name.getAttribute("value"),firstname);
		// RegistrationPage.Lastname_Box(driver).sendKeys(lastname);
		 regis.last_name.sendKeys(lastname);
		 Assert.assertEquals(regis.last_name.getAttribute("value"),lastname);
		// RegistrationPage.Password_Box(driver).sendKeys(password);
		 regis.cuspassword.sendKeys(password);
		 Assert.assertEquals(regis.cuspassword.getAttribute("value"),password);
		  String[] date1=dateofbirth.split("/");
		 Select selectDays = new Select(regis.Day);
		 selectDays.selectByValue(date1[0]);
		 
		 Select selectMonths = new Select(regis.Month);
		 selectMonths.selectByValue(date1[1]);
		 
		 Select selectYears = new Select(regis.Year);
		 selectYears.selectByValue(date1[2]);
		 
		 //RegistrationPage.Company_Box(driver).sendKeys(company);
		 regis.Company.sendKeys(company);
		 Assert.assertEquals(regis.Company.getAttribute("value"),company);
		// RegistrationPage.Address1_Box(driver).sendKeys(address1);
		 regis.address_1.sendKeys(address1);
		 Assert.assertEquals( regis.address_1 .getAttribute("value"),address1);
		// RegistrationPage.Address2_Box(driver).sendKeys(address2);
		 regis.address_2.sendKeys(address2);
		 Assert.assertEquals( regis.address_2.getAttribute("value"),address2);
		// RegistrationPage.City_Box(driver).sendKeys(city);
		 regis.cuscity.sendKeys(city);
		 Assert.assertEquals( regis.cuscity.getAttribute("value"),city);
		 Select selectstate = new Select(regis.State);
		 selectstate.selectByVisibleText(state);
		 
		// RegistrationPage.Postcode_Box(driver).sendKeys(postcode);
		 regis.PostCode.sendKeys(postcode);
		 Assert.assertEquals(regis.PostCode.getAttribute("value"),postcode);
		 Select selectcountry = new Select(regis.Country);
		 selectcountry.selectByVisibleText(country);
		 
		// RegistrationPage.Other_Box(driver).sendKeys(other);
		 regis.Other.sendKeys(other);
		 Assert.assertEquals( regis.Other.getAttribute("value"),other);
		// RegistrationPage.Phone_Box(driver).sendKeys(phone);
		 regis.Phone.sendKeys(phone);
		 Assert.assertEquals(regis.Phone.getAttribute("value"),phone);
		 //RegistrationPage.Mobile_Box(driver).sendKeys(mobile);
		 regis.Mobile.sendKeys(mobile);
		 Assert.assertEquals(regis.Mobile.getAttribute("value"),mobile);
		// RegistrationPage.Register_Box(driver).click();
		 regis.Submit.click();
		 element=LoginPage.Successreg_Link(driver, wait);
		 if (element==null) {
			 return false;
		 }
		 else {
			 System.out.println("passed registration");
		
			 ExcelAccess.writeintoconfig(email, password);
			 return true;
		 }

		 
	}
	public static boolean cartAdding(String email,String password){
		if(browser.equals("chrome")){
			AcceptPage.accept_click(driver, wait).click();
		}
		HomePage.Signin_Link(driver,wait).click();
		LoginPage.Login_Email(driver).sendKeys(email);
		LoginPage.Login_Password(driver).sendKeys(password);
		LoginPage.Login_Button(driver).click();
		AddtocartPage.Tshirt_Link(driver, wait).click();
		
			AddtocartPage.Add_Link(driver,wait).click();
		
		
			element=AddtocartPage.Success_Add(driver, wait);
			if(element==null){
				return false;
			}
			else{
				System.out.println("added successfully");
				return true;
			}
	}
	public static void dividedByException() {
		int i = 1 / 0;
	}
	
}
