package com.selenium.functions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;

public class BrowserOperations extends Testbase{
	
public static void openBrowser(String url,String browser){
		
	 /*  File file = new File(System.getProperty("user.dir")+System.getProperty("file.separator")+"src\\com\\selenium\\config\\Path.properties");
		Properties prop = new Properties();
		FileInputStream input = null;
		try {
			input = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		try {
			prop.load(input);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		if(browser.equals("chrome")){
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+System.getProperty("file.separator")+"driver\\chromedriver.exe");
			driver=new ChromeDriver();
		}
		else if(browser.equals("ie")){
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			capabilities.setCapability("allow-blocked-content", true);
			capabilities.setCapability("allowBlockedContent", true);

			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+System.getProperty("file.separator")+"driver\\IEDriverServer.exe");
			driver=new InternetExplorerDriver();
		}
		//driver.get(prop.getProperty("url"));
		driver.get(url);
		wait= new WebDriverWait(driver, 100);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	   
				
	}
	public static void closeBrowser(){
	
		driver.quit();
	}
	
}