package com.selenium.functions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import com.selenium.base.Testbase;

public class ExcelAccess extends Testbase{
	
	public static void writeintoconfig(String userName,String passWord){
		
		 File file = new File(System.getProperty("user.dir")+System.getProperty("file.separator")+"src\\com\\selenium\\config\\Usercredentials.properties");
			Properties prop = new Properties();
			FileOutputStream output =null;
			
			    try {
					output = new FileOutputStream(file);
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				prop.setProperty("Username", userName);
				prop.setProperty("Password", passWord);
				try {
					prop.store(output, null);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		}
		public static Object[][] read(){
			File file = new File(System.getProperty("user.dir")+System.getProperty("file.separator")+"src\\com\\selenium\\config\\Usercredentials.properties");
			Properties prop = new Properties();
			Object[][] value=null;
			FileInputStream input = null;
			try {
				input=new FileInputStream(file);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				prop.load(input);
				value=new Object[1][2]; 
				value[0][0]=prop.getProperty("Username");
				value[0][1]=prop.getProperty("Password");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return value;
			
		}

}
