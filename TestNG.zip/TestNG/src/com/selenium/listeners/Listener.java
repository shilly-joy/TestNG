package com.selenium.listeners;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;

public class Listener implements ITestListener,ISuiteListener,IInvokedMethodListener {

	//execute before the main test start
	@Override
	public void onTestStart(ITestResult result) {
		// TODO Auto-generated method stub
		System.out.println("The execution of the main test starts now");

	}

	//execute only when test success
	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		printTestResults(result);
	}

	//execute only when test fails
	@Override
	public void onTestFailure(ITestResult result) {
		// TODO Auto-generated method stub
		printTestResults(result);
	}

	//execute only when test skip
	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		printTestResults(result);
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	//execute before test start
	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		Reporter.log("About to begin executing Test " + context.getName(), true);
	}

	//execute after test finish
	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		Reporter.log("Completed executing test " + context.getName(), true);
	}
	private void printTestResults(ITestResult result) {

		Reporter.log("Test Method resides in " + result.getTestClass().getName(), true);

		if (result.getParameters().length != 0) {

			String params = " ";

			for (Object parameter : result.getParameters()) {

				params += parameter.toString() + ",";

			}

			Reporter.log("Test Method had the following parameters : " + params, true);

		}

		String status = null;

		switch (result.getStatus()) {

		case ITestResult.SUCCESS:

			status = "Pass";

			break;

		case ITestResult.FAILURE:

			status = "Failed";

			break;

		case ITestResult.SKIP:

			status = "Skipped";

		}

		Reporter.log("Test Status: " + status, true);

	}
	//It will execute before the Suite start
	@Override
	public void onStart(ISuite suite) {
		// TODO Auto-generated method stub
		Reporter.log("About to begin executing Suite " + suite.getName(), true);
	}
	//execute after suite finish
	@Override
	public void onFinish(ISuite suite) {
		// TODO Auto-generated method stub
		Reporter.log("About to end executing Suite " + suite.getName(), true);
	}

	//execute before calling every method
	@Override
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
		// TODO Auto-generated method stub
		String msg = "About to begin executing following method : " + returnMethodName(method.getTestMethod());

		Reporter.log(msg, true);
	}

	//execute after calling every method
	@Override
	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
		// TODO Auto-generated method stub

		String msg = "Completed executing following method : " + returnMethodName(method.getTestMethod());

		Reporter.log(msg, true);
	}
	
	//return method names
	private String returnMethodName(ITestNGMethod method) {

		return method.getRealClass().getSimpleName() + "." + method.getMethodName();

	}

}
